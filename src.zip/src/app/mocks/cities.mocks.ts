import { City } from "../core/interface/city";
export const CITIES : Array <City> = [
    {
        name : 'DELHI',
        forecast :{
            conditions :'Super Hot',
            wind :{
                speed : 10,
                direction: 'north-west'
            },
            temperature: {
                day:{
                    min:20,
                    max:45
                },
                night:{
                    min:5,
                    max:10
                }
            }
        }
    },
    {
        name : 'GOA',
        forecast :{
            conditions :'Sunny',
            wind :{
                speed : 15,
                direction: 'South-west'
            },
            temperature: {
                day:{
                    min:20,
                    max:22
                },
                night:{
                    min:5,
                    max:8
                }
            }
        }
    },
    {
        name : 'PUNE',
        forecast :{
            conditions :'Cloudy',
            wind :{
                speed : 18,
                direction: 'north-west'
            },
            temperature: {
                day:{
                    min:15,
                    max:18
                },
                night:{
                    min:5,
                    max:8
                }
            }
        }
    }
];