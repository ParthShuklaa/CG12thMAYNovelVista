import { Component, OnInit } from '@angular/core';
import { City } from '../core/interface/city';
import { CityService } from '../core/services/city.service';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.scss']
})
export class WeatherComponent implements OnInit {
  cities : Array<City> = [] ;// Empty array of cities
  ChosenCity : any ;// Variable for saving selected city

   constructor( private  cityService : CityService ) { } // injecting city service to a private variable

  ngOnInit(){
    this.cities = this.cityService.getCities(); //on component initiliaze get data from the service to local variable 
  }
  onChooseCity(index : number) : void {
    console.log(index);
    this.ChosenCity = index;
  }

}
