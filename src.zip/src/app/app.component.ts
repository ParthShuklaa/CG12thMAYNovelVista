import { Component } from '@angular/core';
// import { City } from './core/interface/city';
// import { CITIES } from './mocks/cities.mocks';
// import { CityService } from './core/services/city.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'weather-app';
}
