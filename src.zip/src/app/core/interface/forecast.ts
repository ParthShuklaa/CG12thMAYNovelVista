export interface Forecast {//So that we can import later in component

conditions : string;
wind:{
    speed : number;
    direction : string;
}
temperature : {
    day:{
        min : number;
        max : number;
    },
    night:{
        min: number;
        max: number;
    }
 };
}
//With the hep of interface we are declaring the datasctructure that needs to be shown