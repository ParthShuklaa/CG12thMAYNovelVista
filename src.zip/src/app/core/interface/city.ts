//here name of the city should include forecast also
import { Forecast } from "./forecast"; 
export interface City {
    name: string;
    forecast : Forecast;
}
