import { Injectable } from '@angular/core';
import { CITIES } from 'src/app/mocks/cities.mocks';
import { City } from '../interface/city';

@Injectable({
  providedIn: 'root'
})
export class CityService {

//constructor() { }
 getCities(): Array<City>{
   return CITIES;
   //This method will return array of type cities
   //here we have to use  API for onsuming data through HTTP request
 }
}
